import os
import openai
from flask import Flask, request
from dotenv import load_dotenv
from telegram import Update
from telegram.ext import (
    Application, CommandHandler, MessageHandler, ContextTypes, filters
)
import asyncio

load_dotenv()

TELEGRAM_TOKEN = os.getenv("TELEGRAM_TOKEN")
OPENAI_API_KEY = os.getenv("OPENAI_API_KEY")
WEBHOOK_URL = f"https://{os.getenv('PYTHONANYWHERE_DOMAIN')}/bot"

openai.api_key = OPENAI_API_KEY
flask_app = Flask(__name__)
app = Application.builder().token(TELEGRAM_TOKEN).build()

async def start(update: Update, context: ContextTypes.DEFAULT_TYPE):
    await update.message.reply_text("Привет! Я Алина — нейро-чемпион по продажам 💬\nНапиши мне любой вопрос!")

async def handle_message(update: Update, context: ContextTypes.DEFAULT_TYPE):
    user_input = update.message.text
    try:
        response = openai.ChatCompletion.create(
            model="gpt-4",
            messages=[
                {"role": "system", "content": "Ты — эксперт по продажам, нейроассистент по имени Алина."},
                {"role": "user", "content": user_input}
            ],
            temperature=0.7,
            max_tokens=1000,
        )
        answer = response.choices[0].message.content.strip()
    except Exception as e:
        answer = f"⚠️ Ошибка от OpenAI: {e}"

    await update.message.reply_text(answer)

app.add_handler(CommandHandler("start", start))
app.add_handler(MessageHandler(filters.TEXT & ~filters.COMMAND, handle_message))

@flask_app.post("/bot")
async def webhook_handler():
    if request.method == "POST":
        await app.update_queue.put(Update.de_json(request.get_json(force=True), app.bot))
    return "ok"

async def set_webhook():
    await app.bot.set_webhook(url=WEBHOOK_URL)

if __name__ == "__main__":
    asyncio.run(set_webhook())