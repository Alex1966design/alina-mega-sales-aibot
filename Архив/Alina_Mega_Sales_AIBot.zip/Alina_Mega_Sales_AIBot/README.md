# Alina Mega Sales AI Bot

Telegram-бот на Flask с Webhook и OpenAI GPT-4.  
Развёрнут на PythonAnywhere: https://alexzerocoder.pythonanywhere.com/bot

## Стек
- Python 3.10+
- Flask (Webhook-сервер)
- Telegram Bot API (python-telegram-bot)
- OpenAI API
- PythonAnywhere

## Установка

1. Установите зависимости:
```bash
pip install -r requirements.txt
```

2. Добавьте `.env` файл с переменными:
```
TELEGRAM_TOKEN=your_telegram_token
OPENAI_API_KEY=your_openai_key
PYTHONANYWHERE_DOMAIN=ваш_домен.pythonanywhere.com
```

3. Настройте Webhook:
```bash
python main.py
```

4. Бот будет принимать команды по адресу:
```
https://<ваш_домен>.pythonanywhere.com/bot
```